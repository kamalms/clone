export const environment = {
  production: true,
  supabaseUrl: '',
  supabaseKey: '',
};
