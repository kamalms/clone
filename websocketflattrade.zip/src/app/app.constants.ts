export class FlatTradeURLs {
  private static primeURL ="https://piconnect.flattrade.in/PiConnectTP/";
  public static GETTOKENURL = "https://authapi.flattrade.in/trade/apitoken";
  public static APIKEY = "e86a56517fc64172a4f3d91b437d57b0";
  public static SECRETKEY = "2023.90a6eb79011a42889d20f977ca8bbb4abdf835ccecf761e7";
  public static USERDETAILS =`${FlatTradeURLs.primeURL}UserDetails`;
  public static SEARCHSCRIPS =`${FlatTradeURLs.primeURL}SearchScrip`;
  public static PLACEORDER =`${FlatTradeURLs.primeURL}PlaceOrder`;
  public static TIMEPRICESeries =`${FlatTradeURLs.primeURL}TPSeries`;
  public static GETQUOTES =`${FlatTradeURLs.primeURL}GetQuotes`;
  public static GETINDEXLIST =`${FlatTradeURLs.primeURL}GetIndexList`;
  public static GETENABLEDGTTORDERLIST =`${FlatTradeURLs.primeURL}GetEnabledGTTs`;
  public static GetPendingGTTOrder =`${FlatTradeURLs.primeURL}GetPendingGTTOrder`;
  public static PositionBook =`${FlatTradeURLs.primeURL}PositionBook`;
  public static FundsPayOutReq =`${FlatTradeURLs.primeURL}FundsPayOutReq`;
  public static SetAlert =`${FlatTradeURLs.primeURL}SetAlert`;
  public static ModifyAlert =`${FlatTradeURLs.primeURL}ModifyAlert`;
  public static GetPendingAlert =`${FlatTradeURLs.primeURL}GetPendingAlert`;
  public static PlaceOCOOrder =`${FlatTradeURLs.primeURL}PlaceOCOOrder`;



}
